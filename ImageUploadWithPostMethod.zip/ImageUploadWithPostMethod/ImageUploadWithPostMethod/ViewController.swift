//
//  ViewController.swift
//  ImageUploadWithPostMethod
//
//  Created by Mac on 04/10/18.
//  Copyright © 2018 Mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtid: UITextField!
    
    @IBOutlet weak var txtname: UITextField!
    
    @IBOutlet weak var txtadd: UITextField!
    
    @IBOutlet weak var txtmob: UITextField!
    
    @IBOutlet weak var img: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnimg(_ sender: Any)
    {
    }
    @IBAction func btnInsert(_ sender: Any)
    {

        let image = UIImageJPEGRepresentation(img.image!, 2)
        let base64str = image?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
        let url = URL(string: "")
        let dic = ["emp_id":txtid.text!,"emp_name":txtname.text!,"emp_add":txtadd.text!,"emp_mob":txtmob.text!,"image":base64str!]
        do {
            let jsondata = try JSONSerialization.data(withJSONObject: dic, options: [])
            var request = URLRequest(url: url!)
            request.addValue(String(jsondata.count), forHTTPHeaderField: "Content-Length")
            request.httpBody = jsondata
            request.httpMethod = "POST"
            let session = URLSession.shared
            let datatask = session.dataTask(with: request, completionHandler: { (data1, resp, err) in
                DispatchQueue.main.async {
                    let strrep = String(data: data1!, encoding: String.Encoding.utf8)
                    print(strrep ?? "fugiugh")
                }
            })
        datatask.resume()
        }
        
        catch  {
            
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

